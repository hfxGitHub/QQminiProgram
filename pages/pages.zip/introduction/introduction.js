Page({
    data:{
        toContent: '/pages/Content/content',
        toHome: '/pages/home/home',
        text:"协会介绍",
        src:"1.png",
        _active:1,
        animation:{},
        scrollTop:false,
        backImgHeight:0,
        contentData:{
            createTime:"成立时间",
            TimeContent:"1999年",
            belongTo:"挂靠单位",
            belongToContent:"西南科技大学",
            aimTo:"建设宗旨",
            aimToContent:"承诺自然，用心呵护每一片绿，宣传环保，保护环境",
            famousActivity:"品牌活动",
            famousActivityContent:[{
                value:"第一届绿色营——走近王朗关注大熊猫"
            },{
                value:"第二届绿色营——亲临自然情系草原"
            },{
                value:"第三届绿色营——三江情缘之“关注沱江,保护长江中上游生态屏障”"
            },{
                value:"第四届绿色营——秦岭中部非法采金调查"
            },{
                value:"第五届绿色营——三江情缘之“岷江生态行”"
            },{
                value:"第六届绿色营——三江情缘之“关注嘉陵，保护湿地”"
            },{
                value:"第七届绿色营——“环保重建感恩行，科学发展由我先”灾区人居考察"
            },{
                value:"第八届绿色营——呵护旱后生命之源，探索僳僳风情变迁"
            },{
                value:"第九届绿色营——探索鲁班水库污染“原”，寻求生态经济和谐路"
            },{
                value:"第十届绿色营——关注桉树发展现状，探索嘉农桉树产业前景/防患于未然，关注绵阳第二水源"
            },{
                value:"第十一届绿色营——呵护白鹭，探索白鹭生存现状 /防污杜渐，关注仙海生态旅游"
            },{
                value:"第十二届绿色营——基于国家级水利风景区——武都水库污染风险调研"
            },{
                value:"第十三届绿色营——聚焦高原明珠，共建生态藏区"
            }]
        },
        // 左右滑动
        touchDot:0,
        nth:0,
    },
    onReady: function () {
        this.animation = qq.createAnimation({
            "duration":300,
        })
        this.setData({
            backImgHeight:425 / 750 * qq.getSystemInfoSync().windowWidth
        })
    },
    onPageScroll: function (ev) {
        if(ev.scrollTop>this.data.backImgHeight){
            this.setData({scrollTop:true})
        }else{this.setData({scrollTop:false})}
    },
    changeIntroduction: function () {
        this.animation.translate(0,0).step();
        this.setData({
            animation:this.animation.export(),
            _active:1,
            nth:0,
        })
    },
    changeLatest: function () {
        this.animation.translate(375/750*qq.getSystemInfoSync().windowWidth,0).step()
        this.setData({
            animation:this.animation.export(),
            _active:2,
            nth:1,
        })
    },
    backHomePage: function () {
        qq.navigateBack({
            url:'../index/index',
        })
    },

    // 左右滑动切换界面交互
    touchStart: function (e) {
        const that = this;
        this.setData({
            touchDot:e.touches[0].pageX,
        })
    },
    touchMove: function (e) {
        var touchMove = e.touches[0].pageX;
        if(touchMove - this.data.touchDot <= -50 && this.data.nth!=1){
            this.animation.translate(375/750*qq.getSystemInfoSync().windowWidth,0).step()
            this.setData({
                animation:this.animation.export(),
                _active:2,
                nth:1,
            })
        }
        if(touchMove - this.data.touchDot >= 50 && this.data.nth!=0){
            this.animation.translate(0,0).step();
            this.setData({
                animation:this.animation.export(),
                _active:1,
                nth:0,
            })
        }

    }
})